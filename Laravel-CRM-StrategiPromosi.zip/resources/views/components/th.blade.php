<th {{ $attributes->merge(['class' => 'border-2 p-2']) }}>
	{{ $slot }}
</th>