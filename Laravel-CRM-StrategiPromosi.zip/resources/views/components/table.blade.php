<table {{ $attributes->merge(['class' => 'w-full border p-5']) }}>
	{{ $slot }}
</table>
