<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Test Login</title>
</head>
<body>
	{{ Auth::user()->nama_pengguna }}<br>
	{{ Auth::user()->hak_akses }}<br>
	{{ Auth::user()->username }}<br>

</body>
</html>