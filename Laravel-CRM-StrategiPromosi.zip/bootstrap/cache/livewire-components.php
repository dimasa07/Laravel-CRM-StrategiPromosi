<?php return array (
  'admin.kelola-user' => 'App\\Http\\Livewire\\Admin\\KelolaUser',
  'nav-menu' => 'App\\Http\\Livewire\\NavMenu',
  'ppsb.kelola-alternatif' => 'App\\Http\\Livewire\\Ppsb\\KelolaAlternatif',
  'ppsb.kelola-kriteria' => 'App\\Http\\Livewire\\Ppsb\\KelolaKriteria',
  'ppsb.kelola-pendaftar' => 'App\\Http\\Livewire\\Ppsb\\KelolaPendaftar',
  'ppsb.kelola-penilaian' => 'App\\Http\\Livewire\\Ppsb\\KelolaPenilaian',
  'ppsb.kelola-rincian-biaya' => 'App\\Http\\Livewire\\Ppsb\\KelolaRincianBiaya',
  'user.update-profil' => 'App\\Http\\Livewire\\User\\UpdateProfil',
);