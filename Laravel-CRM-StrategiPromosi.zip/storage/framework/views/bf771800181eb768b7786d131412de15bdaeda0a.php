<table <?php echo e($attributes->merge(['class' => 'w-full border p-5'])); ?>>
	<?php echo e($slot); ?>

</table>
<?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Laravel-CRM-StrategiPromosi/resources/views/components/table.blade.php ENDPATH**/ ?>