<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Test Login</title>
</head>
<body>
	<?php echo e(Auth::user()->nama_pengguna); ?><br>
	<?php echo e(Auth::user()->hak_akses); ?><br>
	<?php echo e(Auth::user()->username); ?><br>

</body>
</html><?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Laravel-CRM-StrategiPromosi/resources/views/test.blade.php ENDPATH**/ ?>