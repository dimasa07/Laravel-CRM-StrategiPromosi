<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
	<?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="bg-black/80">
	<nav class="h-14 bg-black relative border-b border-white/50">
		<div class="flex h-full absolute">
			<img src="<?php echo e(asset('img/logo.JPG')); ?>" class="self-center h-10 mx-3" alt="">
			<span class="self-center text-3xl font-bold text-white">Arcancia</span>
		</div>
		<div class="h-full flex absolute right-3 select-none">
			<button class="border border-white rounded-2xl hover:border-white/50 bg-white/10 hover:bg-black text-white hover:text-white/80 self-center px-5 py-1 font-bold">REGISTER</button>
			<button class="border border-white rounded-2xl hover:border-white/50 bg-green-500 hover:bg-green-600 text-white hover:text-white/80 self-center px-5 py-1 font-bold ml-2">LOGIN</button>
		</div>
	</nav>
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('photo-contest')->html();
} elseif ($_instance->childHasBeenRendered('4MAFIEe')) {
    $componentId = $_instance->getRenderedChildComponentId('4MAFIEe');
    $componentTag = $_instance->getRenderedChildComponentTagName('4MAFIEe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4MAFIEe');
} else {
    $response = \Livewire\Livewire::mount('photo-contest');
    $html = $response->html();
    $_instance->logRenderedChild('4MAFIEe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Laravel-CRM-StrategiPromosi/resources/views/home.blade.php ENDPATH**/ ?>