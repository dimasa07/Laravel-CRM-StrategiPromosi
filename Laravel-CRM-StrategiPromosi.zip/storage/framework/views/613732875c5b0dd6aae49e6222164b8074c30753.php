<div class="text-center">
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
</div>
<?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Arcancia/resources/views/livewire/my-component.blade.php ENDPATH**/ ?>