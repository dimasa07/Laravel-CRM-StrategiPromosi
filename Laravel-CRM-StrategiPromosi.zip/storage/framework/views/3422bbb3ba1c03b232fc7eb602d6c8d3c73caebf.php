<th <?php echo e($attributes->merge(['class' => 'border-2 p-2'])); ?>>
	<?php echo e($slot); ?>

</th><?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Laravel-CRM-StrategiPromosi/resources/views/components/th.blade.php ENDPATH**/ ?>