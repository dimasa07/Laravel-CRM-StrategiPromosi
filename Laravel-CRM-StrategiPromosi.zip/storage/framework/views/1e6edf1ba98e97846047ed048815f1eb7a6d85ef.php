<div>
    <h2 class="text-2xl font-bold">Data Job</h2>
    <hr>
    <form wire:submit.prevent="save">
        <input type="text" wire:model="job.name">
        <select wire:model="job.rank">
            <option value="" selected>Please select</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
        </select>
        <input type="submit" value="Add" />
    </form>
    <hr>
    <form wire:submit.prevent="update">
        <table border="1" cellspacing="2">
            <tr>
                <td>No</td>
                <td>Name</td>
                <td>Rank</td>
                <td>Action</td>
            </tr>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><input type="text" wire:model.defer="jobs.<?php echo e($index); ?>.name"></td>
                <td><input type="text" wire:model.defer="jobs.<?php echo e($index); ?>.rank"></td>
                <td>
                    <button type="button" wire:click="update(<?php echo e($index); ?>)">Update</button> |
                    <button wire:click="delete(<?php echo e($job); ?>)">Delete</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </form>
</div>
<?php /**PATH /media/flemy/DATA/Linux-DEVELOPMENT/Framework/Arcancia/resources/views/livewire/data-job.blade.php ENDPATH**/ ?>